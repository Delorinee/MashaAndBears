#include "CupSensors.h"
#include "Logger.h"


CupSensor sensors[] = {
    {5, false}, // Датчик 1 на пине 2
    {22, false}, // Датчик 2 на пине 3
    {21, false}, // Датчик 3 на пине 4
    {16 , false}  // Датчик 4 на пине 5
};

const byte cupCount = sizeof(sensors) / sizeof(sensors[0]);



void cupSensors_Init() {
    for (byte i = 0; i < cupCount; i++) {
        pinMode(sensors[i].pin, INPUT);
        sensors[i].state = false; // Изначально считаем, что стаканчиков нет
    }
}

void cupSensors_UpdateStates() {
    for (byte i = 0; i < cupCount; i++) {
        sensors[i].state = !digitalRead(sensors[i].pin);
    }
}

bool cupSensors_getCupState_byIndex(byte btnIndex){
	if (btnIndex > cupCount){
		LOG(LOG_LEVEL_ERROR, "Wrong button index");
		return 0;
	}
  cupSensors_UpdateStates();
	return sensors[btnIndex].state;
}

int cupSensors_getCupsState(){
	int result = 0;
	for (byte i = 0; i < cupCount; i++){
		result = result << 1;
		result += sensors[i].state;
	}
	return result;
}


void cupSensors_LogStates() {
    for (byte i = 0; i < cupCount; i++) {
        logMessage(LOG_LEVEL_DEBUG, "Sensor on pin %d: %s",
                   sensors[i].pin, sensors[i].state ? "Cup present" : "No cup");
    }
}
