#ifndef CUPMOVEMENT_SERVO_H
#define CUPMOVEMENT_SERVO_H

#define SERVO_CUP_PIN 32 //23

void cupMovementServo_Initialize();
void cupMovementServo_MoveToAngle(int angle);

#endif
