#include "Nextion.h"
#include "Commands.h"

#include <Arduino.h>
#include "EasyNextionLibrary.h"

EasyNex myNex(Serial);

void nextion_init(){
  myNex.begin(9600);
}


void nextion_mainScreen(){
  myNex.writeStr("page main");
}
 

void nextion_waitScreen(){
  myNex.writeStr("page exe1");
}


void nextion_removeScreen(){
  myNex.writeStr("page exe2");
}

void nextion_loadScreen(){
  myNex.writeStr("page exe3");
}


void nextion_tick(){
  myNex.NextionListen();
}

void trigger0(){
  Commands_Process("1");
}

void trigger1(){
  Commands_Process("2");
}

void trigger2(){
  Commands_Process("3");
}

void trigger3(){
  Commands_Process("4");
}

void trigger4(){
  Commands_Process("5");
}

void trigger5(){
  Commands_Process("6");
}

void trigger6(){
  Commands_Process("C");
}

void trigger7(){
  Commands_Process("S");
}
