//#include <Servo.h>
#include <ESP32Servo.h>
#include "CupMovement_Servo.h"
#include "Logger.h"

Servo servoCup;

#define MIN_US 500
#define MAX_US 2500

void cupMovementServo_Initialize() {
    servoCup.attach(SERVO_CUP_PIN, MIN_US, MAX_US);
    LOG(LOG_LEVEL_INFO, "Сервопривод для узла перемещения стаканчиков инициализирован.");
}

void cupMovementServo_MoveToAngle(int angle) {
    String msg;
    //String msg = String("Заданный угол: ") + angle;
    //LOG(LOG_LEVEL_DEBUG, msg.c_str());
    angle = constrain(angle, 0, 270);
    int us = map(angle, 0, 270, 500, 2500);
    msg = String("Сервопривод: перемещение на угол ") + angle;
    LOG(LOG_LEVEL_DEBUG, msg.c_str());
    msg = String("Сервопривод: сигнал в мкс = ") + us;
    LOG(LOG_LEVEL_DEBUG, msg.c_str());
    servoCup.writeMicroseconds(us);
}


/*

//#include <Servo.h>
#include <ESP32Servo.h>
#include "CupMovement_Servo.h"
#include "Logger.h"

Servo servoCup;

#define MIN_US 500
#define MAX_US 2500

void cupMovementServo_Initialize() {
    servoCup.attach(SERVO_CUP_PIN, MIN_US, MAX_US);
    LOG(LOG_LEVEL_INFO, "Сервопривод для узла перемещения стаканчиков инициализирован.");
}

void cupMovementServo_MoveToAngle(int target_angle) {
    String msg;
    //String msg = String("Заданный угол: ") + target_angle;
    //LOG(LOG_LEVEL_DEBUG, msg.c_str());
	int start_angle = constrain(servoCup.read(), 0, 270); 
    target_angle = constrain(target_angle, 0, 270);
	bool delta_angle = target_angle - start_angle;
	
	msg = String("Сервопривод: целевой угол: ") + target_angle;
    LOG(LOG_LEVEL_DEBUG, msg.c_str());
	
	if (delta_angle == 0){
		return;
	}
	if (delta_angle > 0){
		for (int angle = start_angle; angle <= target_angle; angle++){
			int us = map(angle, 0, 270, 500, 2500);
			servoCup.writeMicroseconds(us);
			Serial.print(angle);Serial.print("\t");Serial.println(us); 
			delay(20);
		}
	}
	else{
		for (int angle = start_angle; angle >= target_angle; angle--){
			int us = map(angle, 0, 270, 500, 2500);
			Serial.print(angle);Serial.print("\t");Serial.println(us); 
			servoCup.writeMicroseconds(us);
			delay(20);
		}
	}
}
*/