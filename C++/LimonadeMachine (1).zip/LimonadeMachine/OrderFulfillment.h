//OrderFulfillment.h

#ifndef ORDER_FULFILLMENT_H
#define ORDER_FULFILLMENT_H

#include <Arduino.h>

void serve_drink(size_t cupId, const char *recipeName);
void serve_order();
void load_cups();
		

#endif //ORDER_FULFILLMENT_H
