#ifndef CUP_SENSOR_H
#define CUP_SENSOR_H

#include <Arduino.h>

struct CupSensor {
    uint8_t pin;   // Пин датчика
    bool state;    // Состояние датчика
};


extern const byte cupCount;


void cupSensors_Init();
void cupSensors_UpdateStates();
bool cupSensors_getCupState_byIndex(byte btnIndex);
int cupSensors_getCupsState();
void cupSensors_LogStates();


#endif
