#ifndef NEXTION_MODULE_H
#define NEXTION_MODULE_H

#include <Arduino.h>

void nextion_init();
void nextion_mainScreen();
void nextion_waitScreen();
void nextion_removeScreen();
void nextion_loadScreen();
void nextion_tick();

/*
void trigger0();
void trigger1();
void trigger2();
void trigger3();
void trigger4();
void trigger5();
void trigger6();
void trigger7();
*/

#endif
