#ifndef COMMANDS_H
#define COMMANDS_H

#include <Arduino.h>
#include "OrderQueue.h"


// Основная функция обработки команды
void Commands_Process(const char* cmd);

#endif
