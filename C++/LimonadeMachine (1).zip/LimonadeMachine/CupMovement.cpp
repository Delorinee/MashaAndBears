#include "CupMovement.h"
#include "CupMovement_Servo.h"
#include "Logger.h"

//SERVO TURN TIMEOUT
#define CUPMOVEMENT_MOVE_TIMEOUT 1500

// Константы для углов перемещения
#define HOME_POSITION 			  5
#define FIRST_CUP_DOSE_POS 		10 //20
#define SECOND_CUP_DOSE_POS 	50 //60
#define THIRD_CUP_DOSE_POS 		85 //95
#define FOURTH_CUP_DOSE_POS 	120 //130

#define FIRST_CUP_RELEASE_POS 	135
#define SECOND_CUP_RELEASE_POS 	173
#define THIRD_CUP_RELEASE_POS 	218
#define FOURTH_CUP_RELEASE_POS 	263


const unsigned int cupDosePositions[] = {
	FIRST_CUP_DOSE_POS,
	SECOND_CUP_DOSE_POS,
	THIRD_CUP_DOSE_POS,
	FOURTH_CUP_DOSE_POS
};
constexpr size_t cupDoseCount = sizeof(cupDosePositions) / sizeof(cupDosePositions[0]);

const  unsigned int cupReleasePositions[] = {
	FIRST_CUP_RELEASE_POS,
	SECOND_CUP_RELEASE_POS,
	THIRD_CUP_RELEASE_POS,
	FOURTH_CUP_RELEASE_POS
};
constexpr size_t cupReleaseCount = sizeof(cupReleasePositions) / sizeof(cupReleasePositions[0]);


void cupMovement_Init() {
    cupMovementServo_Initialize();
    LOG(LOG_LEVEL_INFO, "Высокоуровневая часть узла перемещения стаканчиков инициализирована.");
}



void cupMovement_doseCup(size_t cupId){
	if (cupId >= cupDoseCount){
		LOG(LOG_LEVEL_ERROR, "Invalid cup ID: %zu. Maximum ID is %zu.", cupId, cupDoseCount - 1);
		return;
	}
	LOG(LOG_LEVEL_DEBUG, "Перемещение чаши №%d в зону дозирования..", cupId);
	cupMovementServo_MoveToAngle(cupDosePositions[cupId]);
	delay(CUPMOVEMENT_MOVE_TIMEOUT);
	LOG(LOG_LEVEL_DEBUG, "Перемещение чаши №%d в зону дозирования завершено!", cupId);
}



void cupMovement_serveCup(size_t cupId){
	if (cupId >= cupReleaseCount){
		LOG(LOG_LEVEL_ERROR, "Invalid cup ID: %zu. Maximum ID is %zu.", cupId, cupReleaseCount - 1);
		return;
	}
	LOG(LOG_LEVEL_DEBUG, "Перемещение чаши №%d в зону выдачи..", cupId);
	cupMovementServo_MoveToAngle(cupReleasePositions[cupId]);
	delay(CUPMOVEMENT_MOVE_TIMEOUT);
	LOG(LOG_LEVEL_DEBUG, "Перемещение чаши №%d в зону выдачи завершено!", cupId);
}




void cupMovement_HomePos() {
    LOG(LOG_LEVEL_DEBUG, "Высокоуровневая команда: переход в домашнюю позицию.");
    cupMovementServo_MoveToAngle(HOME_POSITION);
}

void cupMovement_FirstPos() {
    logMessage(LOG_LEVEL_DEBUG, "Высокоуровневая команда: выдача первого стакана.");
    cupMovementServo_MoveToAngle(FIRST_CUP_DOSE_POS);
}

void cupMovement_SecondPos() {
    logMessage(LOG_LEVEL_DEBUG, "Высокоуровневая команда: выдача второго стакана.");
    cupMovementServo_MoveToAngle(SECOND_CUP_DOSE_POS);
}

void cupMovement_ThirdPos() {
    logMessage(LOG_LEVEL_DEBUG, "Высокоуровневая команда: выдача третьего стакана.");
    cupMovementServo_MoveToAngle(THIRD_CUP_DOSE_POS);
}

void cupMovement_FourthPos() {
    logMessage(LOG_LEVEL_DEBUG, "Высокоуровневая команда: выдача четвертого стакана.");
    cupMovementServo_MoveToAngle(FOURTH_CUP_DOSE_POS);
}
